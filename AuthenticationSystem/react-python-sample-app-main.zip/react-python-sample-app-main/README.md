# react-python-sample-app

The application has a python server and a react-client. 

## Start Server
cd server

python app.py

## Start client

cd react-client

npm start